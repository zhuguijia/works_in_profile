#include <string>
#include "eletronics.h"

using namespace std;

class clothing : public product
{
public:
    clothing(string _name, double _price, int _surplus, string _describsion, float _discount);
};


class T_Shirt : public clothing
{    
public:
    T_Shirt(double _price, int _surplus, string _describsion, float _discount);
};


class Pants : public clothing
{    
public:
    Pants(double _price, int _surplus, string _describsion, float _discount);
};


class Skirt : public clothing
{    
public:
    Skirt(double _price, int _surplus, string _describsion, float _discount);
};
