#include <string>

using namespace std;

class product
{                             //�����Ʒ���� 
private:
      string name;                 //��Ʒ���� 
      double price;               //��Ʒԭ��
      int surplus;                 //��Ʒʣ���� 
      string describsion;             //��Ʒ���� 
      float discount;
public: 
      product();
      product(string _name, double _price, int _surplus, string _describsion, float _discount);
      virtual double getPrice();
      string getName();
      int getSurplus();
      string getDescribsion();
      virtual float getDiscount();
      void setSurplus(int _surplus);
};                               
