#include <string>
#include "product.h"

using namespace std;

class book : public product
{
public:
    book(string _name, double _price, int _surplus, string _describsion, float _discount);
};


class TongXinYuanLi : public book
{    
public:
    TongXinYuanLi(double _price, int _surplus, string _describsion, float _discount);
};


class CaoZuoXiTong : public book
{    
public:
    CaoZuoXiTong(double _price, int _surplus, string _describsion, float _discount);
};


class BianYiYuanLi : public book
{    
public:
    BianYiYuanLi(double _price, int _surplus, string _describsion, float _discount);
};
