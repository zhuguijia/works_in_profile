#include "clothing.h"

clothing::clothing(string _name, double _price, int _surplus, string _describsion, float _discount):product(_name, _price, _surplus, 
    _describsion, _discount)
{
}


T_Shirt::T_Shirt(double _price, int _surplus, string _describsion, float _discount):clothing("T��", _price, 
    _surplus, _describsion, _discount)
{
}


Pants::Pants(double _price, int _surplus, string _describsion, float _discount):clothing("ţ�п�", _price, 
    _surplus, _describsion, _discount)
{
}


Skirt::Skirt(double _price, int _surplus, string _describsion, float _discount):clothing("ȹ��", _price, 
    _surplus, _describsion, _discount)
{
}
