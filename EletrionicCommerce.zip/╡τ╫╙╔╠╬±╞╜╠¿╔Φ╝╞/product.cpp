#include "product.h"

product::product()
{
    this->name = "";
    this->price = 0;
    this->surplus = 0;
    this->describsion = "";
    this->discount = 0;
}

product::product(string _name, double _price, int _surplus, string _describsion, float _discount)
{
    this->name = _name;
    this->price = _price;
    this->surplus = _surplus;
    this->describsion = _describsion;
    this->discount = _discount;
}

double product::getPrice()
{
    return this->price;
}

string product::getName()
{
    return this->name;
}
int product::getSurplus()
{
    return this->surplus;
}
string product::getDescribsion()
{
    return this->describsion;
}

float product::getDiscount()
{
    return this->discount;
}

void product::setSurplus(int _surplus)
{
    this->surplus = _surplus;
}
