#include <string>
#include "book.h"

using namespace std;

class eletronics : public product
{
public:
    eletronics(string _name, double _price, int _surplus, string _describsion, float _discount);
};


class iPhone5s : public eletronics
{    
public:
    iPhone5s(double _price, int _surplus, string _describsion, float _discount);
};


class XiaoMi2 : public eletronics
{    
public:
    XiaoMi2(double _price, int _surplus, string _describsion, float _discount);
};


class iPhone6Plus : public eletronics
{    
public:
    iPhone6Plus(double _price, int _surplus, string _describsion, float _discount);
};
