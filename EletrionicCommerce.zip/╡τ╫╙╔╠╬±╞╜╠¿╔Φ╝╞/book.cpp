#include "book.h"

book::book(string _name, double _price, int _surplus, string _describsion, float _discount):product(_name, _price, _surplus, _describsion, _discount)
{
}


TongXinYuanLi::TongXinYuanLi(double _price, int _surplus, string _describsion, float _discount):book("ͨ��ԭ��", _price, 
    _surplus, _describsion, _discount)
{
}


CaoZuoXiTong::CaoZuoXiTong(double _price, int _surplus, string _describsion, float _discount):book("����ϵͳ", _price, 
    _surplus, _describsion, _discount)
{
}


BianYiYuanLi::BianYiYuanLi(double _price, int _surplus, string _describsion, float _discount):book("����ԭ��", _price, 
    _surplus, _describsion, _discount)
{
}
