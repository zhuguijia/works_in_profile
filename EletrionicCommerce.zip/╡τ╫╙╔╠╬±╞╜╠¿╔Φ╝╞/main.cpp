#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <vector>
#include "clothing.h"

#define BOOK_DISCOUNT 0.9f
#define ELETRONICS_DISCOUNT 0.95f
#define CLOTHING_DISCOUNT 0.8f

using namespace std;

int main(int argc, char *argv[])
{        
    string type;
    string name;
    double price;
    int surplus;
    string describsion;
    float discount;
   
   while(1)//�û�ѡ���½��ע�� 
   {
    string name,password;
    int i;
    cout<<"��������Ӧ����ţ�"<<endl;
    cout<<"1�����û�ע��"<<endl;
    cout<<"2�������˺ŵ�½"<<endl;
    cin>>i;
    
    if(i==1)//ע�����û� 
    {
        string password1,password2;
        cout<<"�������û�����"<<endl;
        cin>>name;
        
        int judge=0;
        while(judge==0)
        {
            cout<<"���������룺"<<endl;
                   cin>>password1;
            cout<<"���ٴ��������룺"<<endl;
                   cin>>password2;
            if(password1==password2)
               {
                  cout<<"ע��ɹ�,���¼"<<endl;
                  fstream UserInfo("UserInfo.txt", ios::out | ios::app);
                  UserInfo<<name<<" "<<password1<<endl;
                  UserInfo.close();
                  
                    judge=1;
               }
            else
               {
                  cout<<"��������벻һ�£�����������"<<endl;
               }            
        }                
    }
    
    else if(i==2)//��½�˺� 
    {
         cout<<"�������û�����"<<endl;
               cin>>name;
         cout<<"���������룺"<<endl;
               cin>>password;
               
         fstream UserInfo("UserInfo.txt", ios::in);
         string name1,password1;
         int judge = 0;
         while (judge==0&&UserInfo.eof()==0)
         {
                UserInfo>>name1>>password1;
                if (name==name1&&password==password1)
                {
                    judge=1; 
                    cout<<"��½�ɹ�"<<endl;
                }
         }
         UserInfo.close();
         
         if (judge==0)
         {
                cout<<"�û����������������"<<endl;
         }
         else
         {                                                                    
                vector<product> vPurchaseCar;
                vector<product>::iterator iter2;
                    
                while(1)
                {
                    vector<product> vProducts;
                    vector<product>::iterator iter1;                    
                    
                    cout<<"��������Ӧ����ţ�"<<endl;
                    cout<<"1.�鿴��Ʒ"<<endl;
                    cout<<"2.�鿴���ﳵ"<<endl;
                    cout<<"3.�˳���¼"<<endl;
                    int j;
                    cin>>j; 
                    
                    if(j==1)
                    {                 
                        cout<<endl<<"ȫ���鼮"<<BOOK_DISCOUNT * 10<<"��"<<endl;
                        cout<<"ȫ�����Ӳ�Ʒ"<<ELETRONICS_DISCOUNT * 10<<"��"<<endl;
                        cout<<"ȫ����װ"<<CLOTHING_DISCOUNT * 10<<"��"<<endl;
                        cout<<"�Żݻ�����ﳵ��88��8"<<endl<<endl;
                        
                        cout<<"������鿴����Ʒ���1.�鼮 2.���Ӳ�Ʒ 3.��װ"<<endl;
                        int _i;
                        cin>>_i;
                               
                        fstream Product("Product.txt", ios::in);                                                                           
                        if(_i==1)
                        {
                            Product.close();
                            Product.open("book.txt", ios::in);
                        }      
                        else if(_i==2)
                        {
                            Product.close();
                            Product.open("eletronics.txt", ios::in);
                        }
                        else if(_i==3)
                        {
                            Product.close();
                            Product.open("clothing.txt", ios::in);
                        }
                        else
                        {
                            cout<<"�����������������"<<endl;
                            continue;
                        }                                
                        
                        while(Product.eof()==0)
                        {
                            Product>>type>>name>>price>>surplus>>describsion;
                            if (type=="ͼ��"||type=="���Ӳ�Ʒ"||type=="��װ")
                            {         
                                if (name=="ͨ��ԭ��")
                                {
                                    TongXinYuanLi p = TongXinYuanLi(price,surplus,describsion,BOOK_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                                if (name=="����ϵͳ")
                                {
                                    CaoZuoXiTong p=CaoZuoXiTong(price,surplus,describsion,BOOK_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                                if (name=="����ԭ��")
                                {
                                    BianYiYuanLi p=BianYiYuanLi(price,surplus,describsion,BOOK_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                                if (name=="iPhone5s")
                                {
                                    iPhone5s p =iPhone5s(price,surplus,describsion,ELETRONICS_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                                if (name=="XiaoMi2")
                                {
                                    XiaoMi2 p=XiaoMi2(price,surplus,describsion,ELETRONICS_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                                if (name=="iPhone6Plus")
                                {
                                    iPhone6Plus p=iPhone6Plus(price,surplus,describsion,ELETRONICS_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                                if (name=="T��")
                                {
                                    T_Shirt p = T_Shirt(price,surplus,describsion,CLOTHING_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                                if (name=="ţ�п�")
                                {
                                    Pants p=Pants(price,surplus,describsion,CLOTHING_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                                if (name=="ȹ��")
                                {
                                    Skirt p=Skirt(price,surplus,describsion,CLOTHING_DISCOUNT);
                                    vProducts.push_back(p);
                                }
                            }
                        }
                        vProducts.pop_back(); 
                        Product.close();
                        
                        cout<<"���  ��Ʒ����            ���� ���� ��Ʒ����"<<endl<<endl;
                        int k=1;
                        for (iter1=vProducts.begin();iter1!=vProducts.end();++iter1)
                        {
                            cout.setf(ios::left);
                            cout.width(6);
                            cout<<k;
                            
                            cout.setf(ios::left);
                            cout.width(20);
                            cout<<iter1->getName();
                            
                            cout.setf(ios::left);
                            cout.width(5);
                            cout<<iter1->getPrice();
                            
                            cout.setf(ios::left);
                            cout.width(5);
                            cout<<iter1->getSurplus();
                            
                            cout.setf(ios::left);
                            cout.width(30);
                            cout<<iter1->getDescribsion()<<endl; 
                            
                            ++k;                           
                        }
                        cout<<"��������Ʒ��ż��빺�ﳵ������0���أ�"<<endl;
                        cin>>k;
                        
                        if (k == 0)
                        {
                            continue;
                        }
                        
                        int _k=1;
                        for (iter1 = vProducts.begin(); iter1 != vProducts.end(); ++iter1)
                        {
                            if (_k==k)
                            {
                                product p1=*(iter1);
                                vPurchaseCar.push_back(p1);
                                iter1->setSurplus(iter1->getSurplus() - 1);
                            }                        
                            ++_k;
                        }
                        cout<<"�����ӵ����ﳵ"<<endl;
                        
                        fstream Product2("Product.txt", ios::out);
                        if(_i==1)
                        {
                            Product2.close();
                            Product2.open("book.txt", ios::out);
                        }      
                        else if(_i==2)
                        {
                            Product2.close();
                            Product2.open("eletronics.txt", ios::out);
                        }
                        else if(_i==3)
                        {
                            Product2.close();
                            Product2.open("clothing.txt", ios::out);
                        }
                        for(iter1=vProducts.begin(); iter1!=vProducts.end();++iter1)
                        {
                            if(iter1->getName()=="ͨ��ԭ��"||iter1->getName()=="����ϵͳ"||iter1->getName()=="����ԭ��")
                            {
                                if(iter1->getSurplus()>0)
                                {
                                    Product2<<"ͼ��"<<" "<<iter1->getName()<<" "<<iter1->getPrice()<<" "<<iter1->getSurplus()
                                        <<" "<<iter1->getDescribsion()<<endl;
                                }
                            }
                            
                            if(iter1->getName()=="iPhone5s"||iter1->getName()=="XiaoMi2"||iter1->getName()=="iPhone6Plus")
                            {
                                if(iter1->getSurplus()>0)
                                {
                                    Product2<<"���Ӳ�Ʒ"<<" "<<iter1->getName()<<" "<<iter1->getPrice()<<" "<<iter1->getSurplus()
                                        <<" "<<iter1->getDescribsion()<<endl;
                                }
                            }
                            
                            if(iter1->getName()=="T��"||iter1->getName()=="ţ�п�"||iter1->getName()=="ȹ��")
                            {
                                if(iter1->getSurplus()>0)
                                {
                                    Product2<<"��װ"<<" "<<iter1->getName()<<" "<<iter1->getPrice()<<" "<<iter1->getSurplus()
                                        <<" "<<iter1->getDescribsion()<<endl;
                                }
                            }
                        }   
                        Product2.close();                                             
                    }
                    else if(j==2)
                    {
                        float total=0;
                        
                        cout<<"��Ʒ����            ����"<<endl<<endl;
                        for(iter2=vPurchaseCar.begin();iter2!=vPurchaseCar.end();++iter2)
                        {
                            total+=(int)(iter2->getPrice()*iter2->getDiscount());
                            
                            cout.setf(ios::left);
                            cout.width(20);
                            cout<<iter2->getName();
                            
                            cout.setf(ios::left);
                            cout.width(5);
                            cout<<iter2->getPrice()<<endl<<endl;                            
                        }
                        
                        if (total>=88)
                        {
                            total-=8;
                        }
                        
                        cout<<"Ӧ���"<<total<<endl<<endl;   
                        
                        cout<<"1.ȷ�϶���"<<endl;                     
                        cout<<"2.����"<<endl;                     
                        
                        int k;
                        cin>>k;
                        if (k==1)
                        {
                            cout<<"�µ��ɹ�"<<endl;                     
                        }
                    }
                    else if(j==3)
                    {
                        break;
                    }
                }
         }  
    }           
   }
    system("PAUSE");
    return EXIT_SUCCESS;
}
