#include "eletronics.h"

eletronics::eletronics(string _name, double _price, int _surplus, string _describsion, float _discount):product(_name, _price, _surplus, 
    _describsion, _discount)
{
}


iPhone5s::iPhone5s(double _price, int _surplus, string _describsion, float _discount):eletronics("iPhone5s", _price, 
    _surplus, _describsion, _discount)
{
}


XiaoMi2::XiaoMi2(double _price, int _surplus, string _describsion, float _discount):eletronics("XiaoMi2", _price, 
   _surplus, _describsion, _discount)
{
}


iPhone6Plus::iPhone6Plus(double _price, int _surplus, string _describsion, float _discount):eletronics("iPhone6Plus", _price, 
    _surplus, _describsion, _discount)
{
}
